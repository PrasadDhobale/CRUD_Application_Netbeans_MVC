/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author PRASAD
 */
public class Connect {
    
    private String driver = "oracle.jdbc.driver.OracleDriver";
    private String url = "jdbc:oracle:thin:@localhost:1521:xe";
    private String uname = "hr";
    private String passwd = "hr";
    static Connection con;
    public Connection getConnection(){
        
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, uname, passwd);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
}

/*
create table Student
(
 Rno NUMBER PRIMARY KEY,
 Name VARCHAR2(50),
 Passwd VARCHAR2(20)
);
select *from student;

truncate table student;
drop table Student;
*/