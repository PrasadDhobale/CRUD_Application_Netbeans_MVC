/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.*;
/**
 *
 * @author PRASAD
 */
public class StudentDao {
    Connect OCon = new Connect();
    Connection con = null;
    
    public int insert(Student s){
        int status = 0;
        con = OCon.getConnection();
        
        try {
            System.out.println(con);
            String insertQuery = "insert into Student (rno, name, passwd) values (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(insertQuery);
            ps.setInt(1, s.getRno());
            ps.setString(2, s.getSname());
            ps.setString(3, s.getPasswd());
            System.out.println(ps);
            status = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }        
        return status;
    }
    public int update(Student s){
        Connection con = null;
        con = OCon.getConnection();
        int updateStaus = 0;
        try {            
            String updateQuery = "update Student set name = ?, passwd = ? where rno = ?";
            PreparedStatement ps = con.prepareStatement(updateQuery);
            ps.setString(1, s.getSname());
            ps.setString(2, s.getPasswd());
            ps.setInt(3, s.getRno());
            updateStaus = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return updateStaus;
    }

    public int delete(int rno){
        int delStatus = 0;
        Connection con = null;
        Connect Ocon = new Connect();
        con = Ocon.getConnection();
        String deleteQuery = "delete from Student where rno = ?";
        try {
            PreparedStatement ps = con.prepareStatement(deleteQuery);
            ps.setInt(1, rno);
            delStatus = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return delStatus;
    }
}